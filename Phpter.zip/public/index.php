﻿<?php
/**
 * Front Controller
 */

/**
 * Composer
 */
require dirname(__DIR__) . '/vendor/autoload.php';

/**
 * Error and Exception handling
 */
error_reporting(E_ALL);
set_error_handler('Core\Error::errorHandler');
set_exception_handler('Core\Error::exceptionHandler');


$router = new Core\Router();

//Add routes
$router->add('', ['controller' => 'Login', 'action' => 'index']);
$router->add('login', ['controller' => 'Login', 'action' => 'index']);
$router->add('admin', ['controller' => 'Admin', 'action' => 'index']);
$router->add('loginHandler', ['controller' => 'LoginHandler', 'action' => 'login']);
$router->add('register', ['controller' => 'Register', 'action' => 'register']);
$router->add('terminal', ['controller' => 'Terminal', 'action' => 'terminal']);
$router->add('command', ['controller' => 'Command', 'action' => 'command']);
$router->add('command/{controller}/{action}');

$url = $_SERVER['QUERY_STRING'];

$router->dispatch($url);


