<div class="container">
<?php
echo "
<div class=\"row\">
<div class=\"col\"></div>
<div class=\"col\">
<form class=\"form-signin\">
      <div class=\"row align-items-center justify-content-center\">
        <img class=\"mb-1\" src=\"./assets/img/pic.png\" alt=\"\" width=\"200\" height=\"200\">
      </div>
        <div class=\"row align-items-end justify-content-center\">
          <h1 class=\"h3 mb-3 font-weight-normal RTL\">فرم ورود</h1>
        </div>
      <label for=\"inputUsername\" class=\"sr-only\">نام کاربری</label>
      <input type=\"username\" id=\"inputUsername\" class=\"form-control RTL\" placeholder=\"نام کاربری\" required autofocus>
      <br/>
      <label for=\"inputPassword\" class=\"sr-only\">کلمه عبور</label>
      <input type=\"password\" id=\"inputPassword\" class=\"form-control RTL\" placeholder=\"کلمه عبور\" required>
        <br/>
      <button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">ورود</button>
    </form>
    </div>
    <div class=\"col\"></div>
    </div><!-- end of row -->
";
?>
</div>
