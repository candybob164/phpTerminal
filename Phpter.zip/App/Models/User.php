<?php

namespace App\Models;

use PDO;

/**
 * Example user model
 *
 * PHP version 7.0
 */
class User extends \Core\Model
{
    /**
     * Get all the users as an associative array
     * @return array
     */
    public static function getAll()
    {
        $db = static::getDB();
        $stmt = $db->query('SELECT id FROM users');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function isUser($username, $password)
    {
        $db = static::getDB();
        $sha_password = sha1($password);
        $query = "SELECT * FROM users WHERE (Fname LIKE \"$username\") AND (password LIKE \"$sha_password\")";
        $stmt = $db->query($query);

        if (sizeof($stmt->fetchAll()) > 0) {
            return true;
        } else {
            return false;
        }
    }

    public static function getUserRole($username, $password)
    {
        $db = static::getDB();
        $sha_password = sha1($password);

        $query = "SELECT roles.Name,users.Fname FROM users,users_roles,roles,permissions_roles,permissions WHERE users.Id = users_roles.UId AND users_roles.RId = roles.Id AND permissions_roles.RId = roles.Id AND permissions_roles.PId = permissions.Id AND Fname LIKE \"$username\" AND password = \"$sha_password\" LIMIT 1 ";
        $stmt = $db->query($query);

        file_put_contents('../logs/logs.txt', $query);
        $res = $stmt->fetchAll();
        if (count($res) > 0) {
            file_put_contents('../logs/logs.txt',$res[0]['Name']);
            if ($res[0]['Name'] == "admin") {
                return 1; //1 is Admin
            } else if ($res[0]['Name'] == "user") {
                return 0; //0 is user
            } else {
                return -1; //-1 not found
            }
        } else {
            return -1; //-1 not found
        }
    }
}
