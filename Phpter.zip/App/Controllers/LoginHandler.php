<?php

namespace App\Controllers;
/**
 * Login Handler
 */

use App\Models\User;

class LoginHandler extends \Core\Controller
{
    public function loginAction($args = [])
    {
        $res = User::isUser($args['username'], $args['password']);
        if ($res) {
            if (User::getUserRole($args['username'], $args['password']) == 1) {
                //admin
                //start session
                header('Location: admin');
            } else if (User::getUserRole($args['username'], $args['password']) == 0) {
                // user
                // start session
                header('Location: terminal');
            } else {
                header('Location: login');
            }
        } else {
            header('Location: login');
        }
    }
}
