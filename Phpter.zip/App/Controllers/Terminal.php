<?php

namespace App\Controllers;

/**
 * Login Controller
 */

use Core\View;

class Terminal extends \Core\Controller
{
    public function terminalAction()
    {
        $command = "ls ./assets";
        $out = shell_exec($command);
        $arr = array(
            'title' => $command,
            'shellResString' => array($out)
        );
        View::renderTemplate('Home/terminal.html', $arr);
    }

}
