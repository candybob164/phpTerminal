<?php

namespace App\Controllers;
/**
 * Login Controller
 */

use Core\View;

class Admin extends \Core\Controller
{
    public function indexAction()
    {
        $arr = array("admin"=>array("name"=>"reza"));
        View::renderTemplate('Home/admin.html',$arr);
    }

}
