<?php

namespace App\Controllers;
/**
 * Login Controller
 */

use Core\View;

class Login extends \Core\Controller
{
    public function indexAction()
    {
        View::renderTemplate('Home/login.html');
    }

}
